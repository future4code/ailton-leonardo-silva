export const gotoHomePage = (navigate) => {
    navigate("/")
}

// export const gotoQuina = (navigate) => {
//     navigate("/Quina")
// }

// export const gotoMegaSena = (navigate) => {
//     navigate("/MegaSena")
// }

// export const gotoDiaDeSorte = (navigate) => {
//     navigate("/DiaDeSorte")
// }

// export const gotoLotofacil = (navigate) => {
//     navigate("/Lotofacil")
// }

// export const gotoLotomania = (navigate) => {
//     navigate("/Lotomania")
// }

// export const gotoTimemania = (navigate) => {
//     navigate("/Timemania")
// }

// export const gotoError = (navigate) => {
//     navigate("/Error")
// }

// export const goToVoltar = (navigate) => {
//     navigate(-1)
// }