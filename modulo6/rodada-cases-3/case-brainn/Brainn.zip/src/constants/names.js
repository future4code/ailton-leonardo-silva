//Criando o arquivo de nomes de acordo com o Figma do projeto

export const megasenaName = "Mega-Sena"
export const quinaName = "Quina"
export const lotofacilName = "Lotofácil"
export const lotomaniaName = "Lotomania"
export const timemaniaName = "Timemania"
export const diadesorteName = "Dia de Sorte"
